package net.skhu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HwA201635007ApplicationTests {

	@Test
	void contextLoads() {
	}

}
