package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HwA201635007Application {

	public static void main(String[] args) {
		SpringApplication.run(HwA201635007Application.class, args);
	}

}
